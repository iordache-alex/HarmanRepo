import os
import time
import psutil
import datetime
import gzip
import shutil

LOG_FILE = "/var/log/sys_health.log"  
ARCHIVE_DIR = "/var/log/archive_logs"  # Adjust if needed

def send_email():
    print("Simulated Alert")

def log_system_health():
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cpu_usage = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()
    ram_usage = ram.percent
    disk = psutil.disk_usage('/')
    disk_usage = disk.percent

    processes = sorted(psutil.process_iter(['pid', 'name', 'memory_percent']),
                       key=lambda p: p.info['memory_percent'],
                       reverse=True)[:10]
    top_procs = "\n".join([f"{p.info['pid']} {p.info['name']} {p.info['memory_percent']:.2f}%" for p in processes])

    with open(LOG_FILE, 'a') as log:
        log.write(f"[{timestamp}]\n")
        log.write(f"CPU Usage: {cpu_usage}%\n")
        log.write(f"RAM Usage: {ram_usage}%\n")
        log.write(f"Disk Usage: {disk_usage}%\n")
        log.write("Top Processes by Memory:\n")
        log.write(f"{top_procs}\n")
        log.write("-" * 40 + "\n")

    if disk_usage > 80:
        send_email()

def archive_log():
    if not os.path.exists(ARCHIVE_DIR):
        os.makedirs(ARCHIVE_DIR)
    archive_name = os.path.join(ARCHIVE_DIR, f"sys_health_{datetime.datetime.now().strftime('%Y%m%d_%H')}.log.gz")
    with open(LOG_FILE, 'rb') as f_in, gzip.open(archive_name, 'wb') as f_out:
        shutil.copyfileobj(f_in, f_out)
    open(LOG_FILE, 'w').close()  # Clear the log file

def monitor():
    while True:
        log_system_health()
        if datetime.datetime.now().minute == 0:  # Archive at the start of the hour
            archive_log()
        time.sleep(10)  # Sleep for 5 minutes, but 10 seconds for testing

if __name__ == "__main__":
    monitor()
