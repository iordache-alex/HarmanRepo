import os
import subprocess

def run_command(cmd):
    print(f"Running: {cmd}")
    subprocess.run(cmd, shell=True, check=True)

def setup_iot():
    # Create group iotusers
    run_command("sudo groupadd iotusers")

    # Add users user1 and user2
    run_command("sudo useradd -m user1")
    run_command("sudo useradd -m user2")

    # Add users to iotusers group
    run_command("sudo usermod -aG iotusers user1")
    run_command("sudo usermod -aG iotusers user2")

    # Create shared directory
    run_command("sudo mkdir -p /home/iotshared")
    run_command("sudo chown root:iotusers /home/iotshared")
    run_command("sudo chmod 2775 /home/iotshared")
    run_command("sudo setfacl -d -m g:iotusers:rwx /home/iotshared")
    run_command("sudo setfacl -d -m o::r /home/iotshared")

    print("IoT setup complete.")

if __name__ == "__main__":
    setup_iot()
