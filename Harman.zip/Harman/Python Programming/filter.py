import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import os

# --------------------
# Config
# --------------------
input_csv = 'sensor_data_sampled.csv'
output_report = 'sensor_report.txt'
output_graph = 'clean_data_plot.png'

# --------------------
# 1. Read and prepare data
# --------------------
df = pd.read_csv(input_csv)
df['time'] = pd.to_datetime(df['time'])

print("Initial data:\n", df.head())

# --------------------
# 2. Filter out anomalies using Z-score
# --------------------
def filter_outliers_zscore(data, threshold=3):
    z_scores = np.abs(stats.zscore(data))
    mask = (z_scores < threshold).all(axis=1)
    return data[mask]

# Apply filtering
filtered_numeric = filter_outliers_zscore(df[['temperature', 'humidity']])
clean_df = df.loc[filtered_numeric.index]

print(f"Filtered data ({len(clean_df)} rows):\n", clean_df.head())

# --------------------
# 3. Group filtered data by day
# --------------------
clean_df['date'] = clean_df['time'].dt.date
df_grouped = clean_df.groupby('date').mean().reset_index()

# --------------------
# 4. Generate line graph
# --------------------
plt.figure(figsize=(12, 6))
plt.plot(df_grouped['date'], df_grouped['temperature'], label='Temperature (°C)')
plt.plot(df_grouped['date'], df_grouped['humidity'], label='Humidity (%)')
plt.xlabel('Date')
plt.ylabel('Average Readings')
plt.title('Average Temperature and Humidity by Day (Filtered)')
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(output_graph)

print(f"Graph saved as {output_graph}")

# --------------------
# 5. Trend detection and report generation
# --------------------
report_lines = []
report_lines.append("Sensor Data Analysis Report\n")
report_lines.append("="*30 + "\n")
report_lines.append(f"Total rows (initial): {len(df)}\n")
report_lines.append(f"Total rows (after filtering): {len(clean_df)}\n")

for col in ['temperature', 'humidity']:
    mean_val = clean_df[col].mean()
    std_val = clean_df[col].std()
    trend = np.polyfit(np.arange(len(clean_df)), clean_df[col], 1)
    slope = trend[0]
    trend_desc = "increasing" if slope > 0 else "decreasing" if slope < 0 else "stable"

    report_lines.append(f"\n{col.capitalize()} Analysis:\n")
    report_lines.append(f"- Mean: {mean_val:.2f}\n")
    report_lines.append(f"- Standard Deviation: {std_val:.2f}\n")
    report_lines.append(f"- Trend: {trend_desc} (slope = {slope:.4f})\n")

# Write report
with open(output_report, 'w') as f:
    f.writelines(report_lines)

print(f"Report generated as {output_report}")
