import pandas as pd

df = pd.read_csv('sensor_data.csv')

sample_size = 40000

df_sample = df.head(sample_size)

df_sample['time'] = pd.to_datetime(df_sample['time'])

df_sorted = df_sample.sort_values(by='time')

output_file = 'sensor_data_sampled.csv'
df_sorted.to_csv(output_file, index=False)

print(f"Sampled and sorted data of {sample_size} rows saved as '{output_file}'")
